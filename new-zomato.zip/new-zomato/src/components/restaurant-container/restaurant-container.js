import React, { useState } from "react";
import { Alert } from "react-bootstrap";
import RestaurantItem from "../restaurant-item/restaurant-item";
import { searchOrFilterRestaurants } from "../../redux/restaurant/restaurant.utils";

import { connect } from "react-redux";

import "./restaurant-container.css";

const RestaurantContainer = ({ restaurantsItems, initialSearch }) => {
  const [isNotFound, setIsNotFound] = useState(false);

  const renderRestaurants = () => {
    return restaurantsItems.map((item) => (
      <RestaurantItem key={item.id} item={item} />
    ));
  };

  return (
    <div>
      <div className="wrapper-restaurant">
        {restaurantsItems.length === 0 && initialSearch === true ? (
          <Alert variant="danger" style={{ marginTop: "150px" }}>
            No restaurants found, please try again searching.
          </Alert>
        ) : null}
      </div>
      <div className="res-container">
        {restaurantsItems.length > 0 ? renderRestaurants() : null}
      </div>
    </div>
  );
};

const mapStateToProps = ({
  restaurant: { restaurantsItems, searchText, initialSearch },
}) => {
  const filteredResults = searchOrFilterRestaurants(
    restaurantsItems,
    searchText
  );

  return {
    restaurantsItems: filteredResults,
    initialSearch: initialSearch,
  };
};

export default connect(mapStateToProps)(RestaurantContainer);
