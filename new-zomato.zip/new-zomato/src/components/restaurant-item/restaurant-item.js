import React from "react";
import { Card } from "react-bootstrap";

const RestaurantItem = ({ item }) => {
  return (
    <Card key={item.restaurant.id}>
      <Card.Body>
        <Card.Title>{item.restaurant.name}</Card.Title>
        <Card.Text>
          <b>ADDRESS: </b>
          {item.restaurant.location.address}
        </Card.Text>
        <Card.Text>
          <b>CUISINES: </b>
          {item.restaurant.cuisines}
        </Card.Text>
      </Card.Body>
      <Card.Footer>
        <small className="text-muted">
          Timings - {item.restaurant.timings}
        </small>
      </Card.Footer>
    </Card>
  );
};

export default RestaurantItem;
