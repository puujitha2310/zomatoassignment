import React, { useState } from "react";
import { Form, Badge, Button } from "react-bootstrap";

import { connect } from "react-redux";
import {
  fetchRestaurantStartAsync,
  searchRestaurant,
} from "../../redux/restaurant/restaurant.action";

import "./search-restaurant.css";

const Search = ({
  searchRestaurant,
  fetchRestaurantStartAsync,
  isFetching,
}) => {
  const [search, setSearch] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchRequired, setIsSearchRequired] = useState(false);
  const [isFilterEnabled, setIsFilterEnabled] = useState(true);

  const handleChange = (event) => {
    setSearch(event.target.value);
  };

  const searchRestaurants = async () => {
    if (search !== "") {
      setIsSearchRequired(false);
      await fetchRestaurantStartAsync(search);
      setIsFilterEnabled(false);
    } else {
      setIsSearchRequired(true);
    }
  };

  return (
    <div className="topbar-container">
      <h1>
        <Badge variant="danger">ZOMATO</Badge>
      </h1>

      <Form.Control
        size="lg"
        type="text"
        onChange={handleChange}
        value={search}
        placeholder="Enter city to search restaurants in"
        className={isSearchRequired === true ? "required" : null}
      />
      <Form.Control
        size="lg"
        type="text"
        onChange={(event) => {
          setSearchQuery(event.target.value);
        }}
        onKeyUp={(event) => {
          if (event.key === "Enter" || searchQuery === "") {
            searchRestaurant(searchQuery);
          }
        }}
        value={searchQuery}
        placeholder="Search only for breakfast, lunch or dinner"
        disabled={isFilterEnabled}
      />

      <Button
        variant="outline-danger"
        onClick={searchRestaurants}
        disabled={isFetching}
      >
        {isFetching === true ? "...searching" : "SEARCH"}
      </Button>
    </div>
  );
};

const mapDispatchToProps = (dispatch) => ({
  fetchRestaurantStartAsync: (search) =>
    dispatch(fetchRestaurantStartAsync(search)),
  searchRestaurant: (searchQuery) => dispatch(searchRestaurant(searchQuery)),
});

const mapStateToProps = ({ restaurant: { isFetching } }) => ({
  isFetching,
});

export default connect(mapStateToProps, mapDispatchToProps)(Search);
