
// Constants
const SEARCH_RESULT = "SEARCH_RESULT";

// Reducers
const searchResult = {};

export default function reducer(state = searchResult, action) {
  switch (action.type) {
    case SEARCH_RESULT:
      return action.result;
      
       
    default:
      return state;
  }
}


