import axios from "axios";
import RestaurantActionType from "./restaurant.types";

export const searchRestaurant = (searchQuery) => ({
  type: RestaurantActionType.SEARCH_RESTAURANT,
  payload: searchQuery,
});

export const fetchRestaurantStart = () => ({
  type: RestaurantActionType.FETCH_RESTAURANT_START,
});

export const fetchRestaurantSuccess = (restaurants) => ({
  type: RestaurantActionType.FETCH_RESTAURANT_SUCCESS,
  payload: restaurants,
});

export const fetchRestaurantFailure = (errorMessage) => ({
  type: RestaurantActionType.fetchCollectionsFailure,
  payload: errorMessage,
});

export const fetchRestaurantStartAsync = (city) => {
  return (dispatch) => {
    dispatch(fetchRestaurantStart());

    const url =
      "https://developers.zomato.com/api/v2.1/search?entity_type=city&count=50&q=" +
      city;
    const headers = {
      headers: {
        accept: "application/json",
        "user-key": "a0740e30095c221eda1d88e91661e651",
      },
    };

    axios
      .get(url, headers)
      .then((response) => {
        dispatch(fetchRestaurantSuccess(response.data.restaurants));
      })
      .catch((error) => dispatch(fetchRestaurantFailure(error.message)));
  };
};
