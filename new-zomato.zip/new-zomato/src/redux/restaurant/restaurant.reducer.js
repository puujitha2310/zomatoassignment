import RestaurantActionType from "./restaurant.types";

const INITIAL_STATE = {
  restaurantsItems: [],
  isFetching: false,
  errorMessage: undefined,
  searchText: "",
  initialSearch: false,
};

const restaurantReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case RestaurantActionType.FETCH_RESTAURANT_START:
      return {
        ...state,
        isFetching: true,
      };
    case RestaurantActionType.FETCH_RESTAURANT_SUCCESS:
      return {
        ...state,
        isFetching: false,
        initialSearch: true,
        restaurantsItems: action.payload,
      };

    case RestaurantActionType.FETCH_RESTAURANT_FAILURE:
      return {
        ...state,
        isFetching: false,
        errorMessage: action.payload,
      };
    case RestaurantActionType.SEARCH_RESTAURANT:
      return {
        ...state,
        searchText: action.payload,
      };
    default:
      return state;
  }
};

export default restaurantReducer;
