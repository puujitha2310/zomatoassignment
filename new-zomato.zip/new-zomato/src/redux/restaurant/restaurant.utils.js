export const searchOrFilterRestaurants = (items, searchText) => {
  if (searchText == "") {
    return items;
  } else {
    const filteredItems = items.filter((item) => {
      const isVail = item.restaurant.highlights.includes(
        searchText.charAt(0).toUpperCase() + searchText.slice(1)
      );

      if (isVail === true) return item;
    });

    return filteredItems;
  }
};
