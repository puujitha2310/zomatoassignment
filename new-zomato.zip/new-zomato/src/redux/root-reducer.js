import { combineReducers } from "redux";

import restaurantReducer from "./restaurant/restaurant.reducer";

const rootReducer = combineReducers({
  restaurant: restaurantReducer,
});

export default rootReducer;
