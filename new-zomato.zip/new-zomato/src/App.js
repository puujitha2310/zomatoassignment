import React from "react";
import RestaurantContainer from "./components/restaurant-container/restaurant-container";
import Search from "./components/search-restaurant/search-restaurant";
import "./App.css";

export const App = () => {
  return (
    <div className="main-container">
      <Search />
      <RestaurantContainer />
    </div>
  );
};

export default App;
